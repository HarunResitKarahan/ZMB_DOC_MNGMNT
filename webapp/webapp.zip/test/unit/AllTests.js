sap.ui.define([
	"./model/formatter",
	"./model/models"
], function() {
	"use strict";
});